# Templates
#terminology

## Definition
A feature of C++ that allows a type to be passed to a function or a class.

## Example
C++'s standard `vector<T>` is a templated class. `T` is a variable that be almost any type.

