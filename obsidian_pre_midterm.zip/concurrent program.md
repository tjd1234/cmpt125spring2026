#terminology

## Definition
A program that has one, or more, threads of control. If the computer has more than one CPU then the threads might be able to operate in parallel. If there's only one CPU, then the computer will ned to simulate running the threads in parallel, e.g. alternate running each one for a little bit.

Debugging concurrent programs is generally much more difficult than debugging non-current programs (i.e. programs with a single thread of control). [[race condition|Race conditions]] are a major source of bugs in concurrent programs.

## Example
Web servers are usually implemented as concurrent programs. A popular website might have hundreds of people accessing pages from it at the same time, and so web servers typically use one thread of control per user.
