## Definition
A macro is like a function, except that the arguments are passed unevaluated to the macro. This allows them to do things that functions can't do. 

In C++, macros are implemented using the [[pre-processor]]. In general, you need to watch for a number of macro-specific problems in order to use them well, and so they tend to be tricky to use well in C++.

## Example
The `assert(cond)` macro can print the exact expression `cond`. If `assert` were a regular function it would only be able to print `true` or `false` because a function  first evaluates `cond` and then passes the resulting value to the function. A macro doesn't evaluate `cond`, and it gets passed unevaluated, allowing the macro to evaluate it as needed.