## Definition
A **definition** creates an entity. It allocates storage for a variable or provides the full implementation of a function or class. A thing can only usually be defined once.

Note that a definition is also a [[declaration]], but a [[declaration]] is not necessarily a definition.

## Example

```cpp
int x = 0                  // Definition of a variable 
                           // (also a declaration) 
                           
int add(int a, int b) {    // Definition of a function     
   return a + b; 
}  

class Foo {                // Definition of a class
public:   
  void bar(); 
};
```
