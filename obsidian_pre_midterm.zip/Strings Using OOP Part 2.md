In this part we will add the following features to `Oopstr`:

- A default constructor that creates an empty string.
- A copy constructor that copies another `Oopstr`.
- Bounds checking in the `get_char` and `set_char` methods.
- `operator==` for testing if two strings are the same, and `operator!=` for
  checking if they are different. We will also see the `this` pointer, which is
  a special pointer that points to the current object.

## A Default Constructor

A **default constructor** is a constructor that takes no arguments. For a
string, it makes sense for the default constructor to create an empty string:

```cpp
Ooptsr s;
cout << s.size() << "\n"; // prints 0
```

Here is the implementation of the default constructor:

```cpp
struct Oopstr
{
  private:
    char* str;
    int sz;

  public:
    // default constructor that creates an empty string
    Oopstr()
    {
        sz  = 0;
        str = nullptr;
    }

    // ...

}; // struct str
```

## A Copy Constructor

Another useful kind of constructor is the **copy constructor**, which creates a
copy of another `Oopstr`. For example:

```cpp
Oopstr s("Hello");
Oopstr t(s); // t makes a copy of s
println(t); // prints "Hello"
```

Here is the implementation of the copy constructor:

```cpp
struct Oopstr
{
  private:
    char* str;
    int sz;

  public:
    // constructor that creates an empty string
    Oopstr()
    {
        sz  = 0;
        str = nullptr;
    }

    // copy constructor
    Oopstr(const Oopstr& other)
    {
        sz  = other.sz;
        str = new char[sz];
        for (int i = 0; i < sz; i++)
        {
            str[i] = other.str[i];
        }
    }

    // ...

}; // struct str
```

## Bounds Checking in get_char

Recall that `get_char` and `set_char` for reading and writing characters:

```cpp
struct Oopstr
{
    private:
    // ...

    public:
    // ...

    char get_char(int i) const {
        return str[i];
    }

    void set_char(int i, char c) {
        str[i] = c;
    }
};
```

A potential problem with these methods is that they don't check if the index `i`
is out of bounds. If `i` is less than 0, or greater than or equal to the size of
the string, we say that the index `i` is **out of bounds**, and the program is
no longer valid (and so may crash or give wrong results).

To fix this, lets add **bounds checking**. We'll do it by adding a new private
method called `check_index`:

```cpp
#include <cassert>

struct Oopstr
{
  private:
    char* str;
    int sz;

    void check_index(int i) const
    {
        if (!(0 <= i && i < sz))
        {
            throw std::out_of_range("Index out of bounds");
        }
    }

  public:

    // get the character at the given index
    char get_char(int i) const
    {
        check_index(i);
        return str[i];
    }

    void set_char(int i, char c) {
        check_index(i);
        str[i] = c;
    }

    // ...

}; // struct str
```

Now if `get_char` is called with an index that is out of bounds, the program
throws a `runtime_error` exception:

```cpp
Oopstr s("Hello");
cout << s.get_char(10) << "\n"; // throws an exception
```

If an exception is not caught (by a `try/catch` block), the program will crash
with an error message like this:

```
libc++abi: terminating due to uncaught exception of type std::out_of_range: Index out of bounds
```

## operator==, operator!=, and the this pointer

Finally, lets add `operator==` and `operator!=` to check if two `Oopstr` strings are the same.
We want to write code like this:

```cpp
Oopstr s("Hello");
Oopstr t("Hello");
cout << (s == t) << "\n"; // prints true
cout << (s != t) << "\n"; // prints false
```

Here is the implementation of `operator==` and `operator!=`:

```cpp
  private:
    char* str;
    int sz;

    void check_index(int i) const
    {
        if (!(0 <= i && i < sz))
        {
            throw std::out_of_range("Index out of bounds");
        }
    }

  public:

    bool operator==(const Oopstr& other) const
    {
        if (sz != other.sz) {
            return false;
        }

        for (int i = 0; i < sz; i++)
        {
            if (str[i] != other.str[i])
                return false;
        }
        
        return true;
    }

    // this is a pointer that points to the current object
    bool operator!=(const Oopstr& other) const {
        return !(*this == other); 
    }

    // ...

}; // struct str
```

`operator==` returns `true` if the two strings are the same length, have have
the same characters in the same order. Otherwise, it returns `false`.

`operator!=` is the opposite, i.e. it returns `true` if the two strings are
different, and `false` otherwise. 

An important detail of `operator!=` is that it uses the `this` pointer. Every
C++ object has a `this` pointer that points to the object itself, and we need it
here to access the current object, i.e. `*this` is the object itself. Without
`this`, there would be no way to pass the current object to `operator==`.

## Questions

1. What is special about a default constructor?

2. What is special about a copy constructor?

3. What is the `this` pointer, and why is it needed in `operator!=`?

4. Add a new public method called `reverse()` that reverses the string in place.
   For example:

   ```cpp
   Oopstr s("Hello");
   s.reverse();
   println(s); // prints "olleH"
   ```

## Source Code

```cpp
#include <cstring>
#include <iostream>

using namespace std;

struct Oopstr
{
  private:
    char* str;
    int sz;

    void check_index(int i) const
    {
        if (!(0 <= i && i < sz))
        {
            throw std::out_of_range("Index out of bounds");
        }
    }

  public:
    // constructor that creates an empty string
    Oopstr()
    {
        sz  = 0;
        str = nullptr;
    }

    // constructor
    Oopstr(const char* text)
    {
        // get the length of text
        sz = strlen(text);

        // allocate a new array of characters
        str = new char[sz];

        // copy the characters from text to str
        for (int i = 0; i < sz; i++)
        {
            str[i] = text[i];
        }
    }

    // copy constructor
    Oopstr(const Oopstr& other)
    {
        sz  = other.sz;
        str = new char[sz];
        for (int i = 0; i < sz; i++)
        {
            str[i] = other.str[i];
        }
    }

    // destructor
    ~Oopstr()
    {
        delete[] str;
        str = nullptr;
        sz  = 0;
    }

    // get the size of the string
    int size() const { return sz; }

    // get the character at the given index
    char get_char(int i) const
    {
        check_index(i);
        return str[i];
    }

    void set_char(int i, char c)
    {
        check_index(i);
        str[i] = c;
    }

    void append(const Oopstr& other)
    {
        // make a new array of characters of the total size of this and other
        char* new_str = new char[sz + other.sz];

        // copy characters from this to the new array
        for (int i = 0; i < sz; i++)
        {
            new_str[i] = str[i];
        }

        // copy the other characters to the new array
        for (int i = 0; i < other.sz; i++)
        {
            new_str[sz + i] = other.str[i];
        }

        // de-allocate the old array
        delete[] str;

        // make s point to the new array and update the size
        str = new_str;
        sz  = sz + other.sz;
    }

    bool operator==(const Oopstr& other) const
    {
        if (sz != other.sz)
            return false;
        for (int i = 0; i < sz; i++)
        {
            if (str[i] != other.str[i])
                return false;
        }
        return true;
    }

    // this is a pointer that points to the current object
    bool operator!=(const Oopstr& other) const { 
        return !(*this == other); 
    }

}; // struct str

//
// helper functions
//

void print(const Oopstr& s)
{
    for (int i = 0; i < s.size(); i++)
    {
        cout << s.get_char(i);
    }
}

void println(const Oopstr& s)
{
    print(s);
    cout << "\n";
}

void demo1()
{
    cout << "Demo 1 ...\n";
    Oopstr s("Hello");
    cout << s.size() << "\n"; // prints 5
    for (int i = 0; i < s.size(); i++)
    { // prints "Hello"
        cout << s.get_char(i);
    }
    cout << "\n";

    Oopstr t(" World");
    cout << t.size() << "\n"; // prints 6

    s.append(t); // append t to s, modifying s to be "Hello World"

    cout << s.size() << "\n"; // prints 11
    for (int i = 0; i < s.size(); i++)
    { // prints "Hello World"
        cout << s.get_char(i);
    }
    cout << "\n";
}

void demo2()
{
    cout << "Demo 2 ...\n";
    Oopstr s("Hello");
    cout << s.size() << "\n"; // prints 5
    println(s);

    Oopstr t(" World");
    cout << t.size() << "\n"; // prints 6

    s.append(t); // append t to s, modifying s to be "Hello World"

    cout << s.size() << "\n"; // prints 11
    println(s);
}

void demo3()
{
    cout << "Demo 3 ...\n";
    Oopstr s("Hello");
    cout << s.size() << "\n"; // prints 5
    println(s);

    Oopstr t(" World");
    cout << t.size() << "\n"; // prints 6

    s.append(t); // append t to s, modifying s to be "Hello World"

    cout << s.size() << "\n"; // prints 11
    println(s);
}

void demo4()
{
    cout << "Demo 4 ...\n";
    Oopstr s("Hello");
    cout << s.get_char(10) << "\n"; // should crash
}

int main()
{
    // demo1();
    // demo2();
    // demo3();
    demo4();
} // main
```