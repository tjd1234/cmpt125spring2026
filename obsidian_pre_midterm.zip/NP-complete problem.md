#terminology

See [[Easy and Hard Problems]].
