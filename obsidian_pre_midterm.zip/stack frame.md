#terminology 
A collection of values for a function called stored on the [[stack memory|call stack]].