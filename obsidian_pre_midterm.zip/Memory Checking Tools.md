#terminology

## Definition
Programs that check for memory-related errors such as memory leaks and dangling pointers.

On Linux, valgrind is a popular tool for checking for memory errors. For example, `valgrind ./prog` will run `prog` and watch for memory errors.

For macOS, you can use the supplied `leak` to check for memory leaks,  e.g.`leaks -atExit -- ./prog` will run `prog` and print a report when it ends detailing any leaks. 

With the `g++` compiler the `-fsanitize=address` `-fsanitize=leak` options can also find various memory errors.
