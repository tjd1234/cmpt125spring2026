
## Definition
A **declaration** tells the compiler that something exists. It states a name and type, but does not necessarily allocate storage or provide implementation. A thing can be declared any number of times. [[header file|Header files]] typically contain a series of definitions.

Compare this to a [[definition]].

## Example
Here are three different declarations:

```cpp
extern int x;       // Declaration of a variable 
                    // (defined elsewhere) 
int add(int, int);  // Declaration of a function 
                    // (defined elsewhere) 
class Foo;          // Declaration of a class 
                    // (forward declaration)
```