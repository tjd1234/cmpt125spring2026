#terminology

## Definition
A style of testing where you write tests to check if a function satisfies some property of interest. The tests can often be randomly generated, and in practice property testing tools can be an effective way to discover bugs.
## Example
Suppose that `sort(L)` returns a sorted version of list `L`, and `rev(L)` returns `L` reversed, then some properties of `sort` are:
- `sort(sort(L)) == sort(L)`, for any list `L`
- `sort(rev(L)) == sort(L)`, for any list `L`
For instance, for any list `L`, if you sort it twice, then you get the same result as if you sorted it once (known as the [idempotent property](https://en.wikipedia.org/wiki/Idempotence)).

Since these properties hold for *any* list, and so property based testing lets tools often generate lists at random to test that they are true.