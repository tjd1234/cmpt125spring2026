#terminology

## Definition
A pointer variable with the value `nullptr`. De-referencing a null pointer is an error. 

Older versions of C++ use did not have the special value `nullptr`, and  used the value `0` instead. You can still use 0 for a null ptr, but `nullptr` is clearer.

## Example
```cpp
char* cp = new char('M');

cp = nullptr;  // legal, but causes a memory leak!

string* sp = nullptr;

cout << *sp;   // error: cannot de-reference a null pointer
```
