#terminology

## Definition
A synonym for the [[dereferencing operator]].