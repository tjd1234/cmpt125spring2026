#terminology

## Definition
In a computer, **word** is the natural unit of data processed by the computer. There is no standard size for a word since it depends on the computer hardware.

See all also [[bit]] and [[byte]].

## Example
A computer with a 32-bit CPU is said to have a word size of 32, while a 64-bit one has a word size of 64.
