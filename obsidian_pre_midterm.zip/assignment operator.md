#terminology

## Definition
In C++, the assignment operator is `operator=`. A user-defined class can define its own assignment operator.

