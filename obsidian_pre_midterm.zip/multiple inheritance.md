#terminology

## Definition
When a class inherits from two, or more, classes. C++ supports multiple inheritance, but many other languages do not since it is introduces extra complexities.

A fundamental challenge with multiple inheritance is what to do when the base classes being inherited from provided different implementations for the same method. There is no simple rule that can automatically pick the correct implementation to use in the inheriting class.

In contrast, [[single inheritance]] is when a class inherits from exactly one other class.

We will not use multiple inheritance in this course.
