To compile and run C++ programs, you'll want at least these programs installed on your computer:

- `git` is used for version control, and makes it easy to upload/download code on websites like [Github](https://githib.com/).
- `g++` (for Linux) or `c++` (for macOS) are the compilers we're using in this course. A compilers converts C++ source code files into an executable program.
- `make` is a "build tool" that simplifies calling the compiler with the correct
  options.
- A memory checking tool to check for  [[memory leak|memory leaks]]. On Linux,  `valgrind` is a good choice (you can install it using the `apt` command given below), and on macOS `leaks` is good (it should come already installed), e.g. `leaks -atExit -- ./prog` will run `prog` and check for leaks.
- A coding editor, such as the popular (and free!) [Visual Studio Code](https://code.visualstudio.com/). 

For Ubuntu Linux, you can install most of the needed software by typing this command into a terminal:

```bash
sudo apt-get install git g++ make valgrind
```

For macOS, check out [the Homebrew package manager](https://brew.sh) as a way to install any missing software.

Generally, searching the web for "how do I install X on Windows" or "how do I install X on Mac" will lead you to instructions for installing X.

Another program you might want to install is [Fish](http://fishshell.com/), a terminal shell program that many programmers prefer over [Bash](https://en.wikipedia.org/wiki/Bash_(Unix_shell)) (the default shell program on Ubuntu). On Ubuntu Linux you can get it like this:

  ```bash
 sudo apt-get install fish
  ```

On macOS, you should be able to find it through [the Homebrew package manager](https://brew.sh).

To use it, type `fish` in a terminal command line.
## Basic C++ Files
- [hello_world.cpp]: A sample program to test that you've got your environment up and running. See below for how to compile and run it.
- [[course makefile|makefile]]: This stores all the compiler options we are using with g++ in this course. Put a copy of [[course makefile|makefile]] in every folder where you compile C++ files.
- [[cmpt_error.h]]: Contains the helper function `cmpt::error("...")` that intentionally crashes a program with a (hopefully!) helpful error message. See [[hello_world.cpp]] for an example of how to use it.
- [[cmpt_trace.h]]: Contains the `Trace` helper class that prints a message when a function is called and when it returns. It is especially helpful for understanding recursive functions. See the comments in [[cmpt_trace.h]] for an example of how to use it.
## Basic Command-line Commands for the Terminal
In this course we'd like you to work from a **command-line** terminal window, sometimes called a **shell** window. It lets you interactively type commands to run programs.

[BASH](http://en.wikipedia.org/wiki/Bash_(Unix_shell)) is the most common default shell, and when you run a terminal you will see a prompt like this:

```bash
$
```

The `$` indicates the shell is waiting for you to type a command. 

The shell includes a complete programming language and dozens of commands (and you can install hundreds more). Here is a brief summary of basic commands that are often used in the terminal:

| Sample Command | Summary                                             |
| :------------- | :-------------------------------------------------- |
| `pwd`          | print the present working directory                 |
| `ls`           | list the files and folders in the current directory |
| `cd a2`        | change to directory a2                              |
| `rm old.cpp`   | delete the file old.cpp                             |
| `cp a1.cpp a1` | copy file a1.cpp to the folder a1                   |
| `man g++`      | display the manual page for the g++ command         |
| `less a1.cpp`  | display contents of a file one page at a time       |
| `cat a1.cpp`   | display contents of a file (unpaged)                |
| `time ./a1`    | display running time of program a1                  |

You can find lots of online help learning about the Linux command-line. For example, [this tutorial](http://www.ibm.com/developerworks/linux/library/l-lpic1-103-3/index.html) and [this tutorial](http://cht.sh/) both discuss many basic Linux commands, with helpful examples. AI also tends to be good at generating commands from English descriptions. 
## Running C++ Programs in the Command Line Terminal
Lets walk through compiling and running a C++ program. First, download copies of  [[hello_world.cpp]], [[course makefile|makefile]] (make sure to save it with the name `makefile`) and [[cmpt_error.h]] in the folder where you will be writing your program.

To check that you're in the correct folder with the right files, type `pwd` ("present working directory") to see the folder you are in within the terminal: 

```bash
$ pwd
/Users/tjd/Library/courses/125
```
If you are in the wrong folder, using the `cd` ("change directory") command to navigate to the correct folder. Check online if you need help using it, although keep in mind the folder structure of your computer is essentially unique and you need to find the correct folder yourself.

When you are in the correct folder, type `cat hello_world.cpp` to see the contents of [[hello_world.cpp]]:

```cpp
$ cat hello_world.cpp
// hello_world.cpp

#include "cmpt_error.h"
#include <iostream>

using namespace std;

int main() {
    cout << "Hello! How old are you? ";
    int age = 0;

    cin >> age;

    if (age <= 0) {
        cmpt::error("invalid age");
    }

    cout << "That is pretty old!\n";
}
```

Try typing `cat makefile` and `cat cmpt_error.h` as well.

Compile the program using `make`. Assuming the [[makefile]] is in the folder you should see something like this:

```bash
$ make hello
g++  -std=c++17 -Wall -Wextra -Werror -Wfatal-errors -Wno-sign-compare -Wnon-virtual-dtor -g   hello.cpp   -o hello
```

Assuming there are no compiling errors, run the resulting program like this:

```bash
$ ./hello_world
```

Notice you must type `./` first before the name.

## Timing a Program
If you want to time how long it takes a program to run, you can use the `time`
command like this:

```bash
$ time ./hello_world
Hello! How old are you? 10
That is pretty old!

________________________________________________________
Executed in    3.41 secs   fish           external 
   usr time  1300.00 micros  104.00 micros  1196.00 micros 
   sys time  142.00 micros  142.00 micros    0.00 micros 
```

This example uses the [Fish](http://fishshell.com/) shell, and your output may be formatted differently if you are using a different shell.

## File Redirection Using < and >
The `ls` command lists the files and folders in the current directory, e.g.:

```bash
$ ls
a1.h  a1_sol*  a1_sol.cpp  a1.txt  cmpt_error.h  makefile
```

The output of `ls` is printed to the screen, which is known as **standard
output**. In C++, functions like `printf` and `cin` always prints to standard
output.

You can easily write the output of a command use the `>` **re-direction
operator**:

```bash
$ ls > listing.txt
$ cat listing.txt
a1.h
a1_sol*
a1_sol.cpp
a1.txt
cmpt_error.h
listing.txt
makefile
```

The command `ls > listing.txt` re-directs the standard output of `ls` into the file `listing.txt`.

You can also re-direct standard input. That means you can, for example, use a text file of input as the input to a program that reads from standard input
(i.e. the keyboard).

Suppose the program `./age` asks the user for their name and age. You could run it like this:

```bash
$ ./age
What's your name? Bob
How old are you? 20

Hi Bob, 20 is a great age!
```

The program waits while the user types `Chris` (and then presses return), and also while the user types `21` (and then presses return).

Another way to run this program is to first create a file called, say,
`test_input.txt` with this content:

```
Chris
21
```

Then you can use the `<` re-direction operator to have `./age` get its input
from `test_input.txt`:

```bash
$ ./age < sample_input.txt
What's your name? How old are you? 
Hi Bob, 20 is a great age!
```

This can be very useful for testing --- it saves a lot of typing!
