#terminology

## Definition
Implementation inheritance occurs when a class inherits the implementation of a method from a super class.

In general, it is often a good idea to minimize implementation inheritance, or avoid it altogether. Instead, try to use [[Interface inheritance|interface inheritance]] is often simpler, and can result in more flexible programs.

## Example
The `to_str()` method in `Stringable` is non-abstract, and so when `Point` inherits from `Stringable` it is inheriting the implementation of `to_Str()`:

```cpp
class Stringable {
public:
  string to_str() const {return ""};
};


class Point : public Stringable {
   // ... inherited to_str() header can implementation ...
};
```