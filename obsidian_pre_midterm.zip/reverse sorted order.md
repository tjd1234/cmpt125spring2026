#terminology

## Definition
A synonym for [[descending sorted order]].