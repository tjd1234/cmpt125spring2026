---
aliases: [constructors] 
---

#terminology

## Definition
A special method in a class/struct that that creates a new object for that class/struct. 

A constructor "sets up" the object for uses, e.g. it initializes the member variables of an object, as well as any other resources the object might need. 

A method always has the same name as the class, and does not have an explicit return type (not even `void`).

A class/struct can have as many constructors as it likes, as long as the methods all have different parameter lists.

A method always has the same name as the class, and does not have an explicit return type (not even `void`).

A class/struct can have as many constructors as it likes, as long as the methods all have different parameter lists.

Constructors and [[destructor|destructors]] often work together manage memory, or other resources, a pattern called [[resource acquisition is initialization]].

A [[default constructor]] and [[copy constructor]] are special constructors that some classes implement.

## Example
```cpp
struct Point {
    double x = 0;  // member initialization
    double y = 0;  // i.e. x and y are set to 0 by default

    // default constructor
    Point() // x and y are initialized above
    { }

    Point(double a, double b)
    : x(a), y(b)         // initializer list
    { }

    // copy constructor
    Point(const Point& other)
    : Point(other.x, other.y)  // constructor delegation
    { }

    // ...

}; // struct Point