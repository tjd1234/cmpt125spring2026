#terminology

## Definition
A number (or some other non-numeric value, like a `string`) that is written as a literal in the middle of a program, and so whose purpose is unclear.

## Example
 10 is a magic number in these two [[constructor|constructors]]:
 
```cpp
class int_vec {
	// ...
public:
    int_vec() 
    : capacity(10), arr(new int[capacity]), size(0)
    { }

    int_vec(int sz, int fill_value)
    : capacity(10), size(sz)
    {
        // ...
    }

    // ...

}; // class int_vec
```
