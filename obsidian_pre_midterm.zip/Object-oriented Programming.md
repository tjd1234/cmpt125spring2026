---
aliases: OOP
---
[[Object-oriented Programming]], or [[Object-oriented Programming|OOP]] for short, is a popular style of programming that encourages programmers to combine data, and operations on that data, into **objects**. OOP helps make your programs more modular, and also enables useful techniques like inheritance.

An **object** is essentially a value in a program that contains both data and operations on that data. In C++, and an object is like a `struct` value which can have function inside it in addition to variables. In C++ OOP, we usually call these `struct`s **classes** instead of structs, and often the `class` keyword is used instead of `struct`. 

C++ was one of the first mainstream languages to support OOP, and its approach to has been quite influential. An important basic distinction that we should make clear is the following:
- **Objects** exist at *run time*. Objects contain data and operations on that data. They are values that can be passed, returned, modified, copied, and so on.
- **Classes** (or `struct`s), exist at *compile time*. A class is treated as the *type* of the object, and provides a blue print for creating objects. A class tells you what data and operations an object will contain. 
## Classes vs Structs
As mentioned, `struct`s and `class`-es in C++ are almost the same. Both can contain data, and both can contain operations (called [[method|methods]]) that operate on that data. All of the data and operations are called the [[members]] of the `struct` or `class`.

For example:

```cpp
struct Person {
    string name;
    int age;

    string to_string() const {
        return name + " " + std::to_string(age);
    }
};
```

`Person` is a `struct` with 3 members: `name`, `age`, and `to_string`. `name` and `age` are variables, and `to_string` is a [[method]]. The `const` on the header line of `to_string` means that it guarantees to *not* modify a `Person` object when called.

> **Note** We must write `std::to_string`, with `std::` at the front. Otherwise, this would recursively call the `to_string` method and cause an infinite loop.

Here is `Person` written as an equivalent `class`:

```cpp
class Person {
public:
    string name;
    int age;

    string to_string() const {
        return name + " " + std::to_string(age);
    }
};
```

The only difference is that the first line of the `class` is `public:`, which tells the C++ compiler that all the members that follow can read/written by any code that has access to a `Person` object. *By default*, the members of a `struct` are public, while, by default, members of a `class` are private.

If you remove `public:` from the `class` version of `Person`, then all the members will be **private**, which means they  *cannot* be accessed by code outside of the `class`/`struct` (they can only be accessed by other members within that `class`/`struct`).

## Example: The Circle Class
Let's work through an example of create a class step-by-step. We will make a class that represents a circle of some given radius, and at some (x, y) point. The first version is a simple `struct`:

```cpp
struct Circle {
    double x;
    double y;
    double radius;
};
```

You can create and use it with code like this:

```cpp
Circle c{1.0, 2.0, 3.0};

cout << "x=" << c.x << ", y=" << c.y << "\n"; // x=1, y=2
cout << "radius=" << c.radius << "\n";        // radius=3
```
### Adding Some Methods
Now lets add some [[method|methods]] to `Circle` to make it a little more convenient to use. Lets first add a method to calculate the circle's diameter:

```cpp
struct Circle
{
    // data members
    double x;
    double y;
    double radius;

    // methods
    double diameter() const 
    {
       return 2 * radius; 
    }

}; // struct Circle
```

The `diameter` methods is inside the `Circle` struct, and it returns twice the `radius`. All methods can read/write the data members in their class.

Note the keyword `const` in the header. This tells C++ that the method does *not* change the object in any way, i.e. it does not modify any of its variables. By telling C++ that it's `const` the compiler can catch mistakes, e.g. in a more complex method we might accidentally modify a variable. In general, always make methods `const` if you can.

You call methods with the same dot-notation as for data members:

```cpp
Circle c{1.0, 2.0, 3.0};

cout << "x=" << c.x << ", y=" << c.y << "\n"; // x=1, y=2
cout << "radius=" << c.radius << "\n";        // radius=3
cout << "diameter=" << c.diameter() << "\n";  // diameter=6
```

We write `c.diameter()` with `()`-brackets at the end because it is a method call.

Another useful method to add is `area()`, which returns the area of the circle:

```cpp
struct Circle
{
    // data members
    double x;
    double y;
    double radius;

    // methods
    double diameter() const 
    {
       return 2 * radius; 
    }
    
    double area() const 
    { 
       return 3.1415926 * radius * radius; 
    }

}; // struct Circle
```

Like `diameter`, `area` is a `const` method because it does not make any changes to the variables of the object.

Finally, it's often convenient to add printing methods to objects, for debugging. So lets do that here:

```cpp
struct Circle
{
    // data members
    double x;
    double y;
    double radius;

    // methods
    double diameter() const 
    {
       return 2 * radius; 
    }
    
    double area() const 
    { 
       return 3.1415926 * radius * radius; 
    }
    
    void print() const
    {
        cout << "Circle: x=" << x << ", y=" << y 
             << ", radius=" << radius << "\n";
        cout << "        area=" << area() << ", " 
             << "diameter=" << diameter() << "\n";
    }
}; // struct Circle
```
`print` is again `const`. Notice that it calls the other method in `Circle`. All methods in a class can access all the other methods and variables.

Now we can write simple-looking code like this:

```cpp
Circle c{1.0, 2.0, 3.0};
c.print();
```

Which prints:

```
Circle: x=1, y=2, radius=3
        area=28.2743, diameter=6
```

One of the benefits of OOP is that it often results in readable code, which makes it easier for human readers to understand and debug.

Objects are values, and so we can, for instance, use them in vectors:

```cpp
vector<Circle> circles = {Circle{1.0, 2.0, 3.0}, 
                          Circle{4.0, 5.0, 6.0}, 
                          Circle{7.0, 8.0, 9.0}};

double total_area = 0.0;
for (const Circle& c : circles)
{
    c.print();
    total_area += c.area();
}

cout << "\nTotal area: " << total_area << "\n";
```

This prints:

```
Circle: x=1, y=2, radius=3
        area=28.2743, diameter=6
Circle: x=4, y=5, radius=6
        area=113.097, diameter=12
Circle: x=7, y=8, radius=9
        area=254.469, diameter=18

Total area: 395.841
```

### Public and Private
When building large programs it is quite easy to make mistakes such as setting a variable to be the wrong value. For example, the radius of a circle should *never* be negative, but nothing stops us from writing code like this:

```cpp
Circle c{4, 5, 1}; // ok: radius is 1
c.radius = -1;     // oops: negative radius makes no sense
c.print();
```

This prints:

```
Circle: x=4, y=5, radius=-1
        area=3.14159, diameter=-2
```

C++ OOP provides a way to deal with this problem: we can declare any variables or methods as being **private**, which means that code outside the class cannot access them. For code that we do want to allow access to, we declare that as **public**:

```cpp
struct Circle
{
  private:
    // data members
    double x;
    double y;
    double radius;

  public:
    // methods
    double diameter() const 
    { 
        return 2 * radius; 
    }
    
    double area() const 
    { 
        return 3.1415926 * radius * radius; 
    }
    
    void print() const
    {
        cout << "Circle: x=" << x << ", y=" << y 
             << ", radius=" << radius << "\n";
        cout << "        area=" << area() << ", " 
             << "diameter=" << diameter() << "\n";
    }
}; // struct Circle
```

This version lets us write code like this:

```cpp
Circle c{1.0, 2.0, 3.0};
c.print();
```

But it *doesn't* let us write code like this:

```cpp
Circle c{4, 5, 1}; // ok: radius is 1
c.radius = -1;     // compiler error: radius is private
c.print();
```

The compiler will not compile code that is outside of `Circle` that tries to access `radius`. Thus there is not way to set the `radius` to be negative.

There are still a couple of problems with this version of `Circle`. First, it stops  legitimate changes to the radius, e.g.:

```cpp
Circle c{4, 5, 1};
c.radius = 2;      // compiler error: radius is private
```

To fix this, we can add a method that sets the radius:

```cpp
struct Circle
{
  private:
    // data members
    double x;
    double y;
    double radius;

  public:
    // methods
    double diameter() const 
    { 
        return 2 * radius; 
    }
    
    double area() const 
    { 
        return 3.1415926 * radius * radius; 
    }
    
    void print() const
    {
        cout << "Circle: x=" << x << ", y=" << y 
             << ", radius=" << radius << "\n";
        cout << "        area=" << area() << ", " 
             << "diameter=" << diameter() << "\n";
    }
    
    void set_radius(double new_radius)
    {
        if (new_radius > 0)
        {
            radius = new_radius;
        }
        else
        {
            throw runtime_error("radius must be positive");
        }
    }
}; // struct Circle
```

The `set_radius` method checks if the new radius is sensible. If not, it throws a runtime exception. Thus we catch bad radii, but allow positive radii:

```cpp
Circle c{4, 5, 1};
c.set_radius(2);   // ok
c.set_radius(-2);  // runtime error
```

### Constructors
A second problem is that nothing stops us from initializing the radius incorrectly:

```cpp
Circle c{4, 5, -1}; // oops: negative radius is not caught
c.print();
```

To deal with this problem C++ provides a special method called a [[constructor]] that lets the programmer control how an object is initialized:

```cpp
struct Circle
{
  private:
    // data members
    double x;
    double y;
    double radius;

  public:
    // methods
    
    // constructor
    Circle(double init_x, double init_y, double init_radius)
    {
        x = init_x;
        y = init_y;
        set_radius(init_radius);
    }
    
    double diameter() const 
    { 
        return 2 * radius; 
    }
    
    double area() const 
    { 
        return 3.1415926 * radius * radius; 
    }
    
    void print() const
    {
        cout << "Circle: x=" << x << ", y=" << y 
             << ", radius=" << radius << "\n";
        cout << "        area=" << area() << ", " 
             << "diameter=" << diameter() << "\n";
    }
    
    void set_radius(double new_radius)
    {
        if (new_radius > 0)
        {
            radius = new_radius;
        }
        else
        {
            throw runtime_error("radius must be positive");
        }
    }
}; // struct Circle
```

The code looks the same as before, but this time the constructor is called to initialize the values of the `Circle`:

```cpp
Circle c{1.0, 2.0, 3.0};  // ok
Circle d{1.0. 2.0, -3.0}; // runtime error: negative radius
```

Together, this constructor, the use of `set_radius`, and public/private ensure that `Circle` objects will always have a sensible radius.

Note that the name of the constructor is the same as the name of its class, and it has no return type (not even `void`).

### Setters and Getters
It's often (but always) the case that the variables in a class are declared private, and the methods are declared public. That way there is no way for code outside the class to read/write the variables. Outside code can only call the public methods.

So to get access to private variables, we can writer [[setter|setters]] and [[getter|getters]]. A setter is a method that *sets* the value of a variable, and a getter is a method that returns the current value of variable. Since they are methods, you can put whatever code you like in them.

Lets add setters and getters for all the variables in `Circle`:

```cpp
struct Circle
{
  private:
    // data members
    double x;
    double y;
    double radius;

  public:
    // methods
    
    // constructor
    Circle(double init_x, double init_y, double init_radius)
    {
        x = init_x;
        y = init_y;
        set_radius(init_radius);
    }
    
    double diameter() const 
    { 
        return 2 * radius; 
    }
    
    double area() const 
    { 
        return 3.1415926 * radius * radius; 
    }
    
    void print() const
    {
        cout << "Circle: x=" << x << ", y=" << y 
             << ", radius=" << radius << "\n";
        cout << "        area=" << area() << ", " 
             << "diameter=" << diameter() << "\n";
    }
    
    // getters
    double get_x() const { return x; }

    double get_y() const { return y; }

    double get_radius() const { return radius; }
    
    // setters
    void set_x(double new_x) { x = new_x; }
    
    void set_y(double new_y) { y = new_y; }
    
    void set_radius(double new_radius)
    {
        if (new_radius > 0)
        {
            radius = new_radius;
        }
        else
        {
            throw runtime_error("radius must be positive");
        }
    }
}; // struct Circle
```

In this case all the getters are quite simple: they just return their corresponding variable value. The getters are all declared `const` because the don't change the value of any of the variables, they just read them and return copies.

The setters for `x` and `y` are also straightforward, i.e. they just assigned the passed-in value. But the setter for `radius` has an if-statement ensure the radius is always positive. None of the setters none of the setters are declared `const` because they make changes to the object.

### Default and Copy Constructors
`Circle` currently has one constructor, but a class can have as many constructors as you like (assuming the parameter lists are different). One useful constructor is the [[default constructor]] that takes no input:

```cpp
struct Circle
{
  private:
    // data members
    double x;
    double y;
    double radius;

  public:
    // methods
    
    // default constructor
    Circle()
    {
        x      = 0;
        y      = 0;
        radius = 1; // no standard default, so we set it to 1
    }
    
    // constructor
    Circle(double init_x, double init_y, double init_radius)
    {
        x = init_x;
        y = init_y;
        set_radius(init_radius);
    }
    
    // ... 
}; // struct Circle
```
The [[default constructor]] lets us write code like this:

```cpp
Circle c;
c.print();
```

Which prints:

```
Circle: x=0, y=0, radius=1
        area=3.14159, diameter=2
```

Another common and useful constructor is the [[copy constructor]], which makes a copy of `Circle`:

```cpp
struct Circle
{
  private:
    // data members
    double x;
    double y;
    double radius;

  public:
    // methods
    
    // default constructor
    Circle()
    {
        x      = 0;
        y      = 0;
        radius = 1; // no standard default, so we set it to 1
    }
    
    // copy constructor
    Circle(const Circle& other)
    {
        x      = other.x;
        y      = other.y;
        radius = other.radius;
    }
        
    // constructor
    Circle(double init_x, double init_y, double init_radius)
    {
        x = init_x;
        y = init_y;
        set_radius(init_radius);
    }
    
    // ... 
}; // struct Circle
```

The [[copy constructor]] takes another `Circle` as input; it's passed by [[pass by constant reference|constant reference]] to avoid needless copies of the variables in `other`, and to make it clear that no changes are being made to `other`. Then the variables of `other` are copied one at a time into the `Circle` object being constructor.

You can save a bit of code by implementing the [[copy constructor]] using [[constructor delegation]]:

```cpp
Circle(const Circle& other)
// initializer list
: Circle(other.x, other.y, other.radius) // constructor delegation
{ } // empty body
```

This calls the first constructor we added to `Circle`, and the end result is the same as our previous copy constructor.  Notice the `:` after the constructor header. This marks the start of an [[initialization list|initializer list]], which is way for constructors (and only constructors) to initialize their variables. The body of the constructor is empty.

### Destructors
Last, but certainly not least, lets add a [[destructor]] to `Circle`. A [[destructor]] is a special method that is automatically called when an object is deleted (e.g. goes out of scope):

```cpp
struct Circle
{
  private:
    // data members
    double x;
    double y;
    double radius;

  public:
    // methods
    
    // destructor
    ~Circle()
    { 
        cout << "Circle " << x << ", " << y << ", " 
             << radius << " destructor called\n"; 
    }
    
    // ... 
}; // struct Circle
```

If we run this code:

```cpp
void demo()
{
    Circle a;
    Circle b(4, 5, 6);
    a.print();
    p.print();
}
```

It prints:

```
Circle: x=0, y=0, radius=1
        area=3.14159, diameter=2
Circle: x=4, y=5, radius=6
        area=113.097, diameter=12
Circle 4, 5, 6 destructor called
Circle 0, 0, 1 destructor called
```

The [[destructor|destructors]] are called automatically at the end of the `demo` function when the `}` is reached. Destructors are called in reverse order of creation, as the example shows.

In a destructor you should put code that "cleans up" any resources the object used. The `Circle` class doesn't need a destructor, but classes that use `new` and `delete`, or open files which should be closed, often but important code in the destructor. 

An important and useful feature of constructors is that they are called *automatically*, and so a programmer cannot forget to call them. While in some special rare circumstances constructors can be called manually by a programmer, most of the time constructors are never called explicitly, meaning that once they are defined they work automatically. 
### The this Pointer
Every C++ object has a pointer called `this` that points to the object itself. As we will see in other examples, `this` is necessary when we want to refer to the object itself. But it can also be used in regular classes, e.g. many programmers write constructors like this:

```cpp
Circle(double x, double y, double radius)
{
    this->x      = x;
    this->y      = y;
    this->radius = radius;
}
```

Some programmers like this style because `this` makes it clear which variables belong to the current object. 
## Questions
1. In your own words, explain the difference between a 
   - `struct` and a `class`
   - function and a [[method]]
   - a [[const method]], and a non-const method
2. In your own words, describe
   - what *public* and *private* mean when used in a `struct`/`class`
   - what a [[constructor]] is, and how to write one and call one
   - why using [[const method]]s is a good idea
   - what [[getter|getters]] and [[setter|setters]] are
3. In your own words, describe what a [[destructor]] does. When it is called? Why can't a programmer call a [[destructor]] whenever they want?
4. In your own words, describe the `this` pointer. Give an example of how to use it.
5. Add a method called `circumference` to the `Circle` class that returns the circumference of the circle.
6. Modify the `Circle` setters and constructors so that x and y are both restricted to be greater than, or equal to 0, and less than 1000.