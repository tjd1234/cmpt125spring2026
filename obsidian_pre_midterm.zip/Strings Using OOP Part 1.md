Here we will take the code from [[A Function-oriented String Buffer|the StringBuffer example]] and convert it to use [[Object-oriented Programming|object-oriented programming]]. This will solve a number of issues with the [[A Function-oriented String Buffer|previous function-oriented string]], namely:

- By using **public and private members**, we will prevent the programmer from
  accidentally, or on purpose, breaking the string. The programmer will not have direct access to the underlying array of characters, and they will only be able to modify it in ways we allow.
- We'll add a [[destructor]] so that strings are *automatically* de-allocated when they are destroyed or go out of scope. Programmers will no longer need to worry when to manually de-allocate the string.

As before, a good way to start to design this code is to write a hypothetical program that shows how we might use such a string. Let's name these strings `Oopstr`:

```cpp
int main() 
{
    Oopstr s("Hello");

    cout << s.size() << "\n"; // prints 5
    
    for(int i = 0; i < s.size(); i++) { // prints "Hello"
        cout << s.get_char(i);
    }
    cout << "\n";

    Oopstr t(" World");
    cout << t.size() << "\n"; // prints 6

    s.append(t);  // append t to s, modifying s to be "Hello World"
    
    cout << s.size() << "\n"; // prints 11
    
    for(int i = 0; i < s.size(); i++) { // prints "Hello World"
        cout << s.get_char(i);
    }
    cout << "\n";

    // no need to de-allocate s and t, they will be automatically de-allocated when they are destroyed
}
```
## The Oopstr Struct
We'll start with a struct similar to the one we used for the [[A Function-oriented String Buffer|StringBuffer example]]:

```cpp
struct Oopstr
{
  private:
    char* str;
    int sz;

  public:
  // ...

}; // struct Oopstr
```

The `private:` and `public:` sections are used to separate items in the struct into things we want the user to be able to access, and thing we don't want them to access. This stops the user messing with the string pointer or its size, which prevents a whole class of errors.

Another small change is that we've renamed `size` to `sz`. This is because we will shortly add a method called `size()` to the struct. Having both a method and a variable with the same name is confusing, hence the change.
## Methods
Now the big change is that we are going to add [[method|methods]] to the struct. A [[method]] is essentially a function that is part of the struct and can access the struct's member variables. Methods and functions are very similar, but [[method|methods]] are always associated with a particular struct, and can have access to the struct's member variables.
### The Constructor
Now we can implement the [[constructor]]. A [[constructor]] is a special method whose job is to initialize the object. From out sample code above we will use the constructor like this:

```cpp
Oopstr s("Hello");
```

This defines `s` as a new `Oopstr` object initialized to the string "Hello".

A [[constructor]] always has the same name as the struct, and does not have a return type (not even `void`):

```cpp
struct Oopstr
{
  private:
    char* str;
    int sz;

  public:

    // constructor
    Oopstr(const char* text)
    {
        // get the length of text
        sz = strlen(text);

        // allocate a new array of characters
        str = new char[sz];

        // copy the characters from text to str
        for (int i = 0; i < sz; i++)
        {
            str[i] = text[i];
        }
    }

}; // struct Oopstr
```

The input is a C-style string, and the [[constructor]] uses `strlen` to get its length. It then allocates a new array of characters of the same length, and copies the characters from the input string to the new array.

### The Destructor
Now lets add another special method, the [[destructor]]. A [[destructor]] is
responsible for de-allocating the resources used by the object. In our case,
this means deleting the array of characters.

[[destructor|Destructors]] always have the same name as the struct, with a `~` at the start, and no return type (not even `void`):

```cpp
struct Oopstr
{
  private:
    char* str;
    int sz;

  public:

    // constructor
    Oopstr(const char* text)
    {
        // get the length of text
        sz = strlen(text);

        // allocate a new array of characters
        str = new char[sz];

        // copy the characters from text to str
        for (int i = 0; i < sz; i++)
        {
            str[i] = text[i];
        }
    }

    // destructor
    ~Oopstr()
    {
        delete[] str;
        str = nullptr;
        sz  = 0;
    }

}; // struct Oopstr
```

The [[destructor]] deletes the array of characters, and sets the pointer and size to `nullptr` and `0` respectively.

Importantly, the destructor is called *automatically* when the object is deleted. In fact, the destructor should (almost) never be called explicitly. This ensures that underlying array is always deleted correctly: the programmer can't forget to call it, and can't call it too soon, or more than once. The object manages its own memory.
### Getting the Size
Now lets add a method that returns the size of the string:

```cpp
int size() const { 
    return sz; 
}
```

Notice that `const` after the header before the body. This makes `size` a [[const method]], which means that it guarantees that it will not modify the object. If it
did, the compiler would give an error. In general, you should always declare
methods as `const` if they do not modify the object.

Now we can write code like this:

```cpp
int main() 
{
    Oopstr s("Hello");
    cout << s.size() << "\n"; // prints 5
}
```

This prints the size of the string "Hello", which is 5. The destructor for `s`
is automatically called when `s` is deleted, which happens when it goes out of
scope at the end of the `main` function, i.e. when the `}` is reached.
### Getting the Character at a Given Index
Now lets add add the `get_char` method to return a character at a given index.
Since it does not modify the object, we declare it as `const`:

```cpp
struct Oopstr
{
  private:
    char* str;
    int sz;

  public:

    // constructor
    Oopstr(const char* text)
    {
        // get the length of text
        sz = strlen(text);

        // allocate a new array of characters
        str = new char[sz];

        // copy the characters from text to str
        for (int i = 0; i < sz; i++)
        {
            str[i] = text[i];
        }
    }

    // get the character at the given index
    char get_char(int i) const { 
        return str[i]; 
    }

}; // struct Oopstr
```

Now we can write can print strings:

```cpp
int main() 
{
    Oopstr s("Hello");
    
    cout << s.size() << "\n"; // prints 5

    for(int i = 0; i < s.size(); i++) { // prints "Hello"
        cout << s.get_char(i);
    }
    cout << "\n";
}
```

### Appending a String
Finally, lets add the `append` method to append another string to the current string. This is *not* `const` because it modifies the object:

```cpp
struct Oopstr
{
  private:
    char* str;
    int sz;

  public:

    // constructor
    Oopstr(const char* text)
    {
        // get the length of text
        sz = strlen(text);

        // allocate a new array of characters
        str = new char[sz];

        // copy the characters from text to str
        for (int i = 0; i < sz; i++)
        {
            str[i] = text[i];
        }
    }

    // get the character at the given index
    char get_char(int i) const { 
        return str[i]; 
    }

    void append(const Oopstr& other)
    {
        // make a new array of characters of the total size of 
        // this and other
        char* new_str = new char[sz + other.sz];

        // copy characters from this to the new array
        for (int i = 0; i < sz; i++)
        {
            new_str[i] = str[i];
        }

        // copy the other characters to the new array
        for (int i = 0; i < other.sz; i++)
        {
            new_str[sz + i] = other.str[i];
        }

        // de-allocate the old array
        delete[] str;

        // make s point to the new array and update the size
        str = new_str;
        sz  = sz + other.sz;
    }
}; // struct Oopstr
```

The steps for `append` are similar to the ones for the `StringBuffer` `append`. We first create a new array big enough to hold all the characters in both this string and the other string, and then copy both strings into it. Then, we delete the old array and update the pointer and size to point to the new array.

Now we can run the all the code at the start of these notes, with no memory errors!

## Printing the String with Helper Functions
As an example of how we can use `Oopstr`, lets write a `print` (and `println`)
function that prints the string to the console:

```cpp
void print(const Oopstr& s)
{
    for (int i = 0; i < s.size(); i++)
    {
        cout << s.get_char(i);
    }
}

void println(const Oopstr& s)
{
    print(s);
    cout << "\n";
}
```

The `Oopstr` `s` is passed by constant reference, which means no copy of it is
made (so that's fast), and the compiler ensures that `print` does not modify
`s`.

Now the code from the start is a little more readable:

```cpp
Oopstr s("Hello");
cout << s.size() << "\n"; // prints 5
println(s);

Oopstr t(" World");
cout << t.size() << "\n"; // prints 6

s.append(t);

cout << s.size() << "\n"; // prints 11
println(s);
```

## Printing the String with Methods
In object-oriented programming, you often need to decide between making something either a function or a method. Above we made `print` and `println` functions, but we could have made them methods instead. If we did, we would have written them like this:

```cpp
struct Oopstr
{
  private:
    // ...

  public:
    // constructor
    Oopstr(const char* text)
    {
        // ...
    }

    // destructor
    ~Oopstr()
    {
        // ...
    }

    // get the size of the string
    int size() const { 
        return sz; 
    }

    // get the character at the given index
    char get_char(int index) const { 
        // ...
    }

    void append(const Oopstr& other)
    {
        // ...
    }

    void print() const
    {
        for (int i = 0; i < size(); i++)
        {
            cout << get_char(i);
        }
    }

    void println() const
    {
        print();
        cout << "\n";
    }

}; // struct str
```

Both `print` and `println` are `const` methods because they do not modify the object. You call them using dot-notation:

```cpp
Oopstr s("Hello");
cout << s.size() << "\n"; // prints 5
s.println();

Oopstr t(" World");
cout << t.size() << "\n"; // prints 6

s.append(t);

cout << s.size() << "\n"; // prints 11
s.println();
```

In the this case, the difference between `print(s)` and `s.print()` is mainly stylistic, and you can use either. However, if the methods required access to private variables, then you would need to implement them as methods instead of functions (or friend functions, but we won't cover those here).
## Questions
1. What do `private:` and `public:` mean when used in a struct?
2. What is the difference between a method and a function?
3. What is a `const` method?
4. Add a (non-`const`) method called `set_char(i, c)` that sets the character at
   index `i` to `c`. It should return `void`.
5. In the `append` method, if `delete[] str;` is replaced with `delete str;`,
   what will happen?

## Source Code
```cpp
// Oopstr1.cpp

#include <cstring>
#include <iostream>

using namespace std;

struct Oopstr
{
  private:
    char* str;
    int sz;

  public:
    // constructor
    Oopstr(const char* text)
    {
        // get the length of text
        sz = strlen(text);

        // allocate a new array of characters
        str = new char[sz];

        // copy the characters from text to str
        for (int i = 0; i < sz; i++)
        {
            str[i] = text[i];
        }
    }

    // destructor
    ~Oopstr()
    {
        delete[] str;
        str = nullptr;
        sz  = 0;
    }

    // get the size of the string
    int size() const { return sz; }

    // get the character at the given index
    char get_char(int index) const { return str[index]; }

    void append(const Oopstr& other)
    {
        // make a new array of characters of the total size of 
        // this and other
        char* new_str = new char[sz + other.sz];

        // copy characters from this to the new array
        for (int i = 0; i < sz; i++)
        {
            new_str[i] = str[i];
        }

        // copy the other characters to the new array
        for (int i = 0; i < other.sz; i++)
        {
            new_str[sz + i] = other.str[i];
        }

        // de-allocate the old array
        delete[] str;

        // make s point to the new array and update the size
        str = new_str;
        sz  = sz + other.sz;
    }

    void set_char(int index, char c)
    {
        str[index] = c;
    }

    void write() const
    {
        for (int i = 0; i < size(); i++)
        {
            cout << get_char(i);
        }
    }

    void writeln() const
    {
        write();
        cout << "\n";
    }

}; // struct str

//
// helper functions
//
void print(const Oopstr& s)
{
    for (int i = 0; i < s.size(); i++)
    {
        cout << s.get_char(i);
    }
}

void println(const Oopstr& s)
{
    print(s);
    cout << "\n";
}

void demo1()
{
    cout << "Demo 1 ...\n";
    Oopstr s("Hello");
    cout << s.size() << "\n"; // prints 5
    for (int i = 0; i < s.size(); i++)
    { // prints "Hello"
        cout << s.get_char(i);
    }
    cout << "\n";

    Oopstr t(" World");
    cout << t.size() << "\n"; // prints 6

    s.append(t); // append t to s, modifying s to be "Hello World"

    cout << s.size() << "\n"; // prints 11
    for (int i = 0; i < s.size(); i++)
    { // prints "Hello World"
        cout << s.get_char(i);
    }
    cout << "\n";
}

void demo2()
{
    cout << "Demo 2 ...\n";
    Oopstr s("Hello");
    cout << s.size() << "\n"; // prints 5
    println(s);

    Oopstr t(" World");
    cout << t.size() << "\n"; // prints 6

    s.append(t); // append t to s, modifying s to be "Hello World"

    cout << s.size() << "\n"; // prints 11
    println(s);
}

void demo3()
{
    cout << "Demo 3 ...\n";
    Oopstr s("Hello");
    cout << s.size() << "\n"; // prints 5
    s.writeln();

    Oopstr t(" World");
    cout << t.size() << "\n"; // prints 6

    s.append(t); // append t to s, modifying s to be "Hello World"

    cout << s.size() << "\n"; // prints 11
    s.writeln();
}

int main()
{
    // demo1();
    // demo2();
    demo3();
} // main
```