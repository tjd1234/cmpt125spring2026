This site has the lecture notes for **CMPT 125, Spring 2026.** 

[Assignments are posted here when they are ready](https://github.com/tjd1234/cmpt125spring2026)

Course marks, due dates, assignment marking schemes, discussions, announcements, etc. are stored on the course Canvas page.
## Useful Links
This course uses modern C++ in Linux/Unix. Here are some options for getting it to run on your computer:

- **Windows**: we recommend you use [[WSL Windows Subsystem for Linux|the Windows Subsystem for Linux (WSL)]]. It's popular and well-supported with lots of on-line help. 
- **Mac**: you can use the c++ compiler that comes in the Terminal. You can install other tools (like `make`) using [the Homebrew package manager](https://brew.sh). If you really want to run Linux on MacOS you could try using [UTM](https://mac.getutm.app/) to install a Linux distribution (search the web for instructions), but it's probably not worth the trouble for this course.

Once you have Linux/Unix up and running, read how to [[Getting Your C++ Environment Up and Running|get your C++ environment up and running]].

If you run into problems and just can't get Linux running, here are two other suggestions you can try:

- Use Linux in the CSIL lab.
- Use [Repl.it](https://repl.it/~) or a similar site that lets you run C++ in a web page. Note that this might make it difficult to do some of the assignments that require reading/writing files or using a specific makefile.

For editing C++, we recommend you use [VS Code](https://code.visualstudio.com), a popular free editor that can be set up to work nicely with C++ and Linux.
## Lecture Notes and Assignments
- [Presentations and code from lectures is here.](https://github.com/tjd1234/cmpt125spring2026/tree/main/notes)
- [Assignments are posted to this Github repository as soon as they are ready](https://github.com/tjd1234/cmpt125spring2026).
## Lecture Notes 
**The timing of each topic is approximate, and may change a little as we go**. The examples used in some weeks may also change.
### Week 1
- Course overview
- [[C++ Overview|Reviewing C++]]
### Week 2
- [[Calling a function]]
- [[Testing Code]]
### Week 3
- [[Pointers and Memory Management]]
### Week 4
- [[Common pointer problems]], [[C-strings example]]
- Example: [[A Function-oriented String Buffer]]
- Object-oriented string buffer example: [[Strings Using OOP Part 1|Part 1]], [[Strings Using OOP Part 2|Part 2]], [[Strings Using OOP Part 3|Part 3]]
### Week 5
- Object-oriented string buffer example: [[Strings Using OOP Part 1|Part 1]], [[Strings Using OOP Part 2|Part 2]], [[Strings Using OOP Part 3|Part 3]]
- [[Object-oriented Programming]]
### Week 6
- [[Introduction to Inheritance]]
### Week 7
- [[Introduction to Inheritance]]

--------------------------

**Reading week (Feb 16 - 20)**: no lectures or labs

--------------------------
### Week 8
- [[Introduction to Exceptions|Exceptions]]
- [[Separate compilation]], and [[splitting int_vec]] into a `.h` and `.cpp` file.
- [[Namespaces|Namespaces]]
- [[Recursion]]
### Week 9
- Midterm practice
- Midterm!
### Week 10
- [[Recursion]]
### Week 11
- [[Calculating large powers]]
- [[The max function]]
- [[linear search|Algorithms and linear search]]
### Week  12
- [[Basic Sorting]]
- [[Basic Sorting#Binary Search|Binary search]]
- [[O-notation]]
### Week 13
- [[Easy and Hard Problems]]
- [[Using Templates]]
### Week  14
- final exam review
- extra classes if needed
