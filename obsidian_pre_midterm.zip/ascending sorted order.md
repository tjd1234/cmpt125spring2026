#terminology

## Definition
A synonym for [[sorted order]].
