#terminology

## Definition
A variation of [[insertion sort]] where the location of where to insert each element is found using [[binary search]]. 
