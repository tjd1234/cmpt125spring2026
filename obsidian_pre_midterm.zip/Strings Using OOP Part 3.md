In this note we are going to significantly improve the run-time performance of the `append` method at the cost of using a little more memory.

Here is the original `append` method:

```cpp
struct Oopstr
{
    // ...

    void append(const Oopstr& other)
    {
        // make a new array of characters of the total size of this and other
        char* new_str = new char[sz + other.sz];

        // copy characters from this to the new array
        for (int i = 0; i < sz; i++)
        {
            new_str[i] = str[i];
        }

        // copy the other characters to the new array
        for (int i = 0; i < other.sz; i++)
        {
            new_str[sz + i] = other.str[i];
        }

        // de-allocate the old array
        delete[] str;

        // make s point to the new array and update the size
        str = new_str;
        sz  = sz + other.sz;
    }

    // ...
};
```

It works like this:

1. Through `new_str`, it creates an array of characters *exactly* big enough to hold all the characters in both this and the other string.
2. It copies the characters from this string to the new array.
3. It copies the characters from the other string to the new array.
4. It de-allocates the old array.
5. It sets the `str` pointer point to the new array and updates the size.

## Performance of the Original `append` Method

How efficient is this? Let's run a performance test to see. This function reads
in a text file of words and appends them all, one at a time, to an initially
empty string:

```cpp
#include <fstream>

void append_performance_test_Oopstr()
{
    const string filename = "enable1.txt";
    cout << "Performance test for " << filename << " ...\n";
    Oopstr s;
    ifstream words(filename);
    string word;
    while (words >> word)
    {
        s.append(Oopstr(word.c_str()));
    }
    cout << s.size() << " characters in s\n";
}
```

`enable1.txt` is a text file of over 170,000 English words (one per line).

`ifstream` is the standard way of reading a text file in C++. It lets you read
the file the same way as you'd read from `cin`.

When run with the `time` command, it takes **115 seconds** to run on my
computer:

```
$ time ./Oopstr3
Performance test for enable1.txt ...
170025 characters in s

________________________________________________________
Executed in  115.21 secs    fish           external
   usr time  114.33 secs    0.13 millis  114.33 secs
   sys time    0.28 secs    1.22 millis    0.28 secs
```

The final string of all words is 1,570,508 characters long, and uses 1,533 KB of
memory (assuming 1 byte per character and 1024 bytes per KB).

Now let's run the same test again this time using `std::string` instead of
`Oopstr`:

```cpp
void append_performance_test_string()
{
    const string filename = "enable1.txt";
    cout << "Performance test for " << filename << " ...\n";
    string s;
    ifstream words(filename);
    string word;
    while (words >> word)
    {
        s += word;
    }
    cout << s.size() << " characters in s\n";
}
```

```
$ time ./Oopstr3
Performance test for enable1.txt ...
170025 characters in s

________________________________________________________
Executed in   58.58 millis    fish           external
   usr time   52.92 millis  115.00 micros   52.81 millis
   sys time    4.64 millis  977.00 micros    3.67 millis
```

This run took only 59 milliseconds, compared to 115 seconds for the `Oopstr`
version. `std::string` is over 1,900 times faster than `Oopstr`.

While we don't know exactly how `std::string` is implemented, it's likely that
is a common trick: when it allocates a new array, it likely allocates more than
the amount of space needed to store the string, even up to twice as much. This
extra space lets future appends avoid the expensive re-allocation and copying
that `Oopstr` does.

So let's implement this trick in `Oopstr`.


## Making the Array Bigger: Adding a Capacity

To make this change we'll need to do some surgery on the `Oopstr` class. First,
we add a `capacity` variable:

```cpp
struct Oopstr
{
  private:
    char* str;
    int sz;       // number of characters in the string
    int capacity; // size of the array

    // ...
};
```

`sz` is still the number of characters in the string, and `capacity` is the size
of the underlying array. `capacity - sz` is the number of characters in the
array that are not used.

### New Constructors

Now we need to modify a number of the methods to be aware of the new `capacity`
variable. Let's start with the constructor:

```cpp
// default constructor: creates an empty string
Oopstr()
{
    sz       = 0;
    capacity = 10;
    str      = new char[capacity];
}
```

The default constructor creates an empty string with a capacity of 10. Why 10?
It's just a guess. If we make the capacity too big we waste memory, and if we
make it too small we have to resize the array more often. So 10 seems like a
good compromise. In practice you might do some experiments to see what works
best for your application.

Next is the C-style string constructor:

```cpp
// constructor
Oopstr(const char* text)
{
    sz       = strlen(text);
    capacity = sz * 2; // capacity is twice the length of the string
    str      = new char[capacity];

    // copy the characters from text to the array
    for (int i = 0; i < sz; i++)
    {
        str[i] = text[i];
    }
}
```

The capacity is set to twice the length of the string. Again, this is just a
guess, and for some applications more or less extra space might be better.

Here is the copy constructor:

```cpp
// copy constructor
Oopstr(const Oopstr& other)
{
    sz       = other.sz;
    capacity = sz * 2;
    str      = new char[capacity];
    for (int i = 0; i < sz; i++)
    {
        str[i] = other.str[i];
    }
}
```

As with the previous constructors, the capacity is set to twice the size of the
other string.

### New Destructor

The destructor is the same as before, except now it should also set the
`capacity` to 0:

```cpp
~Oopstr()
{
    delete[] str;
    str = nullptr;
    sz  = 0;
    capacity = 0;
}
```

The other methods don't need to be modified, except for `append`.

### The New `append` Method

Now we need to modify the `append` method to take advantage of the new
`capacity` variable. The rules for appending now have two cases:

- If the size of the new string (i.e. `sz + other.sz`) is less than or equal to
  the capacity, then we just append the other string to the end of this string.
  No need to create a new array.
- Otherwise, we create a new array that is twice as big as the new size, and
  copy the current string and other into it.

The second case is expensive, requiring a new array to be created and copied.
But since we are doubling the capacity, it won't happen very often, and,
hopefully, the overall run-time performance will be better.

```cpp
void append(const Oopstr& other)
{
    int new_size = sz + other.sz;

    if (new_size <= capacity)
    {
        // copy the other string to the end of this string
        for (int i = 0; i < other.sz; i++)
        {
            str[sz + i] = other.str[i];
        }
        sz = new_size;
    }
    else // new_size > capacity
    {
        capacity      = new_size * 2; // double the capacity
        char* new_str = new char[capacity];

        // copy characters from this to the new array
        for (int i = 0; i < sz; i++)
        {
            new_str[i] = str[i];
        }

        // copy characters from the other string to the new array
        for (int i = 0; i < other.sz; i++)
        {
            new_str[sz + i] = other.str[i];
        }

        // de-allocate the old array
        delete[] str;

        // make str point to the new array and update the size
        str = new_str;
        sz  = new_size;
    }
} // append
```

A nice feature about the changes we've made is that the code that calls `Oopstr`
doesn't need to change. None of it depends on the private implementation
details. From the calling code's point of view, it's still the same `Oopstr`
class, except now it's more efficient and uses some memory.

### Performance of the New `append` Method

Lets run the performance test on this new implementation. Recall that the test
is to append all 170,000 words in `enable1.txt` into a single string. 

On my computer, this takes about **350 milliseconds** to run. Compared to the
115 seconds it took the original `append` method, this is over **300 times
faster**! This is not as fast as `std::string`, but it's still a significant
improvement, and pretty good for a brand new class (`std::string` has been
improved over decades).

While appending is now much faster, it comes at the cost of using more memory.
The final string of all words has these statistics:

```
  Used: 1570508 bytes, 1533 KB (63.4%)
Unused:  905696 bytes,  884 KB (36.6%)
 Total: 2476204 bytes, 2418 KB ( 100%)
(8 bits per char)
```

In comparison, the original `append` method used 1,533 KB of memory with *no*
unused space. So this new implementation uses 2418 Kb of memory, i.e. about 40%
more memory.

To summarize:

    Original append: 
       115 seconds
       1,533 KB of memory used
       0 KB of memory unused

    New append: 
       350 milliseconds
       2,418 KB of memory used
       884 KB of memory unused

The new implementation is about 300 times faster than the original, and uses
about 40% more memory. In practice, this is often an acceptable trade-off
because it's easier to add more memory to a computer than to make it faster.


## Questions

1. Why is the original `append` method for `Oopstr` not very efficient?

2. What's the difference between `sz` and `capacity` in the `Oopstr` class?

3. In the default constructor, why do we set the capacity to 10?

4. What are the rules of appending in the new `append` method?

5. Why is the new `append` method more efficient than the original?

6. What price does the new `append` method pay for its speed?


## Source Code

```cpp
#include <cassert>
#include <climits>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>

using namespace std;

struct Oopstr
{
  private:
    char* str;
    int sz;       // number of characters in the string
    int capacity; // size of the array

    void check_index(int i) const
    {
        if (!(0 <= i && i < sz))
        {
            throw std::out_of_range("Index out of bounds");
        }
    }

  public:
    // constructor that creates an empty string
    Oopstr()
    {
        sz       = 0;
        capacity = 10;
        str      = new char[capacity];
    }

    // constructor
    Oopstr(const char* text)
    {
        sz       = strlen(text);
        capacity = sz * 2;
        str      = new char[capacity];
        for (int i = 0; i < sz; i++)
        {
            str[i] = text[i];
        }
    }

    // copy constructor
    Oopstr(const Oopstr& other)
    {
        sz       = other.sz;
        capacity = sz * 2;
        str      = new char[capacity];
        for (int i = 0; i < sz; i++)
        {
            str[i] = other.str[i];
        }
    }

    // destructor
    ~Oopstr()
    {
        delete[] str;
        str = nullptr;
        sz  = 0;
        capacity = 0;
    }

    // get the size of the string
    int size() const { return sz; }

    // returns size in bytes and KB, assuming 8 bits per character
    int size_in_bytes() const { return size(); }
    int size_in_KB() const { return size_in_bytes() / 1024; }

    // size of the underlying array
    int total_capacity() const { return capacity; }
    int total_capacity_in_bytes() const { return total_capacity(); }
    int total_capacity_in_KB() const { return total_capacity_in_bytes() / 1024; }

    // returns the percentage of the array that is used
    double pct_used() const { return double(sz) / capacity; }

    // returns the percentage of the array that is unused
    double pct_unused() const { return 1 - pct_used(); }

    // get the character at the given index
    char get_char(int i) const
    {
        check_index(i);
        return str[i];
    }

    void set_char(int i, char c)
    {
        check_index(i);
        str[i] = c;
    }

    void append(const Oopstr& other)
    {
        int new_size = sz + other.sz;

        if (new_size <= capacity)
        {
            // copy the other string to the end of this string
            for (int i = 0; i < other.sz; i++)
            {
                str[sz + i] = other.str[i];
            }
            sz = new_size;
        }
        else // new_size > capacity
        {
            capacity      = new_size * 2; // double the capacity
            char* new_str = new char[capacity];

            // copy characters from this to the new array
            for (int i = 0; i < sz; i++)
            {
                new_str[i] = str[i];
            }

            // copy characters from the other string to the new array
            for (int i = 0; i < other.sz; i++)
            {
                new_str[sz + i] = other.str[i];
            }

            // de-allocate the old array
            delete[] str;

            // make str point to the new array and update the size
            str = new_str;
            sz  = new_size;
        }
    } // append

    bool operator==(const Oopstr& other) const
    {
        if (sz != other.sz)
            return false;
        for (int i = 0; i < sz; i++)
        {
            if (str[i] != other.str[i])
                return false;
        }
        return true;
    }

    // this is a pointer that points to the current object
    bool operator!=(const Oopstr& other) const { return !(*this == other); }

}; // struct str

//
// helper functions
//

void print(const Oopstr& s)
{
    for (int i = 0; i < s.size(); i++)
    {
        cout << s.get_char(i);
    }
}

void println(const Oopstr& s)
{
    print(s);
    cout << "\n";
}

void test1()
{
    cout << "Test 1 ...\n";
    Oopstr s;
    assert(s.size() == 0);
    assert(s == s);

    Oopstr t("Hello");
    assert(t.size() == 5);
    assert(t.get_char(0) == 'H');
    assert(t.get_char(1) == 'e');
    assert(t.get_char(2) == 'l');
    assert(t.get_char(3) == 'l');
    assert(t.get_char(4) == 'o');
    assert(t == t);
    assert(t != s);

    t.append(s);
    assert(t.size() == 5);
    assert(t.get_char(0) == 'H');
    assert(t.get_char(1) == 'e');
    assert(t.get_char(2) == 'l');
    assert(t.get_char(3) == 'l');
    assert(t.get_char(4) == 'o');
    assert(t == t);
    assert(t != s);

    s.append(t);
    assert(s.size() == 5);
    assert(s.get_char(0) == 'H');
    assert(s.get_char(1) == 'e');
    assert(s.get_char(2) == 'l');
    assert(s.get_char(3) == 'l');
    assert(s.get_char(4) == 'o');
    assert(s == s);
    assert(s == t);
    assert(t == s);

    Oopstr u(t);
    assert(u == t);
    assert(t == u);

    Oopstr v("cat");
    Oopstr w("dogs");
    v.append(w);
    assert(v == Oopstr("catdogs"));

    v.append(v);
    assert(v == Oopstr("catdogscatdogs"));

    cout << "... all test1 tests passed\n";
}

void demo0()
{
    cout << "Demo 0 ...\n";
    Oopstr s;
    cout << s.size() << "\n"; // prints 0
    println(s);

    Oopstr t("Hello");
    cout << t.size() << "\n"; // prints 5
    println(t);
}

void demo1()
{
    cout << "Demo 1 ...\n";
    Oopstr s("Hello");
    cout << s.size() << "\n"; // prints 5
    for (int i = 0; i < s.size(); i++)
    { // prints "Hello"
        cout << s.get_char(i);
    }
    cout << "\n";

    Oopstr t(" World");
    cout << t.size() << "\n"; // prints 6

    s.append(t); // append t to s, modifying s to be "Hello World"

    cout << s.size() << "\n"; // prints 11
    for (int i = 0; i < s.size(); i++)
    { // prints "Hello World"
        cout << s.get_char(i);
    }
    cout << "\n";
}

void demo2()
{
    cout << "Demo 2 ...\n";
    Oopstr s("Hello");
    cout << s.size() << "\n"; // prints 5
    println(s);

    Oopstr t(" World");
    cout << t.size() << "\n"; // prints 6

    s.append(t); // append t to s, modifying s to be "Hello World"

    cout << s.size() << "\n"; // prints 11
    println(s);
}

void demo3()
{
    cout << "Demo 3 ...\n";
    Oopstr s("Hello");
    cout << s.size() << "\n"; // prints 5
    println(s);

    Oopstr t(" World");
    cout << t.size() << "\n"; // prints 6

    s.append(t); // append t to s, modifying s to be "Hello World"

    cout << s.size() << "\n"; // prints 11
    println(s);
}

void demo4()
{
    cout << "Demo 4 ...\n";
    Oopstr s("Hello");
    cout << s.get_char(10) << "\n"; // should crash
}

void append_performance_test_Oopstr()
{
    // const string filename = "tenKwords.txt";
    const string filename = "enable1.txt";
    cout << "Performance test for " << filename << " ...\n";
    Oopstr s;
    ifstream words(filename);
    string word;
    while (words >> word)
    {
        s.append(Oopstr(word.c_str()));
    }

    //
    // report the results
    //
    int total_bytes  = s.total_capacity_in_bytes();
    int used_bytes   = s.size_in_bytes();
    int unused_bytes = total_bytes - used_bytes;

    cout << fixed << setprecision(1);
    cout << "  Used: " << setw(7) << used_bytes << " bytes, " << setw(4) << used_bytes / 1024 << " KB ("
         << s.pct_used() * 100 << "%)\n";
    cout << "Unused: " << setw(7) << unused_bytes << " bytes, " << setw(4) << unused_bytes / 1024 << " KB ("
         << s.pct_unused() * 100 << "%)\n";
    cout << " Total: " << total_bytes << " bytes, " << total_bytes / 1024 << " KB ( 100%)\n";
    cout << "(" << CHAR_BIT << " bits per char)\n";
}

void append_performance_test_string()
{
    // const string filename = "tenKwords.txt";
    const string filename = "enable1.txt";
    cout << "Performance test for " << filename << " ...\n";
    string s;
    ifstream words(filename);
    string word;
    while (words >> word)
    {
        s += word;
    }

    //
    // report the results
    //
    int total_bytes  = s.total_capacity_in_bytes();
    int used_bytes   = s.size_in_bytes();
    int unused_bytes = total_bytes - used_bytes;

    cout << fixed << setprecision(1);
    cout << "  Used: " << setw(7) << used_bytes << " bytes, " << setw(4) << used_bytes / 1024 << " KB ("
         << s.pct_used() * 100 << "%)\n";
    cout << "Unused: " << setw(7) << unused_bytes << " bytes, " << setw(4) << unused_bytes / 1024 << " KB ("
         << s.pct_unused() * 100 << "%)\n";
    cout << " Total: " << total_bytes << " bytes, " << total_bytes / 1024 << " KB ( 100%)\n";
    cout << "(" << CHAR_BIT << " bits per char)\n";
}

int main()
{
    // test1();
    // demo0();
    // demo1();
    // demo2();
    // demo3();
    // demo4();
    append_performance_test_Oopstr();
} // main
```
