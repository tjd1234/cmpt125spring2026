Lets create a library of string handling functions that make working with C-style strings a little easier. We're going to call these **string buffers**, where **buffer** is a general programming term that means a region of memory that stores data.

A **C-style string is an array of characters whose final character is `\0`**. They're simple, but they have a number of problems that we would like to fix:

- **Problem 1: C-style strings don't know their own size**. If you don't know the length of a C-style string you can calculate it with `strlen(s)`. This is slow because it must count over every character in `s` until it finds a `'\0'` (the character that marks the end of a string).
    - **Improvement**: Represent strings as a struct that contains both the string and the string's length.
- **Problem 2: allocating and de-allocating C-strings by hand is error-prone**. If you want add/remove characters from a string, then you need to change the size of the underlying array. This can be quite finicky, and be the source of subtle errors.
    - **Improvement**: We'll make this a little easier by using clearly named functions `make_string_buffer` and `destroy_string_buffer` will de-allocate the memory.
- **Problem 3: appending C-style strings is tricky**. When you add two C-style with, say, the `strcat(dest, src)` function, you, the programmer, are responsible for ensuring that the `dest` string array is big enough to also contain the `src` string. 
    - **Improvement**: We'll create an append function that automatically re-sizes the string.

These features will give us a string that is a little easier to use than a C-style string (but not as easy as `std::string`!).
## Thinking about Design
Let's write some hypothetical code to get an idea of how we will use a `StringBuffer`:

```cpp
int main() 
{
    StringBuffer s = make_StringBuffer("Hello");
    cout << s.size << "\n"; // prints 5
    for(int i = 0; i < s.size; i++) { // prints "Hello"
        cout << s.str[i];
    }
    cout << "\n";

    StringBuffer t = make_StringBuffer(" World");
    cout << t.size << "\n"; // prints 6

    append(s, t);  // append t to s, modifying s to be "Hello World"
    
    cout << s.size << "\n"; // prints 11
    for(int i = 0; i < s.size; i++) { // prints "Hello World"
        cout << s.str[i];
    }
    cout << "\n";

    // de-allocate the memory for s and t
    destroy_StringBuffer(s);
    destroy_StringBuffer(t);
}
```

Looking at this code, we can see that we need to implement at least the following:

```cpp
// a struct called StringBuffer that represents the string

make_StringBuffer(const char* text)

make_copy(const StringBuffer& s)

append(StringBuffer& s, const char* text)

destroy_StringBuffer(StringBuffer& s)
```

For now we want to keep things simple, and we can add more functions later if we need them.
## The StringBuffer Struct
The first thing we'll do is create the `StringBuffer` struct. We want a `StringBuffer` to represent a single string, including its length:
```cpp
struct StringBuffer 
{
    char* str;
    int size;
};
```

`str` is a pointer to the underlying array of characters, and `size` is the length of that array. Note that we are **not** using `'\0'` at the end of the array.
## The make_StringBuffer Function

The `make_StringBuffer` function is how we'll create strings, and it will take a regular C-style string as input:

```cpp
#include <cstring>

StringBuffer make_StringBuffer(const char* text)
{
    // get the length of the text
    int len = strlen(text);

    // allocate a new array of characters
    char* str = new char[len]; // no \0 at the end (!)

    // copy the characters from text to str
    for(int i = 0; i < len; i++) {
        str[i] = text[i];
    }

    // return the new StringBuffer
    return StringBuffer{str, len};
}
```

`strlen(s)` is a standard C function that returns the length of a C-style string, and you need to `#include <cstring>` to use it.

Note that the final `return StringBuffer{str, len}` statement does *not* make a copy of the underlying array. It just returns a new copy of the `StringBuffer` struct, which has just a pointer and size. Thus this is quite efficient in both time and memory usage.
### Copying a StringBuffer
`make_StringBuffer` creates a new `StringBuffer` given a regular C-style string. Another common way to create a `StringBuffer` is to copy another `StringBuffer`. We'll do that with the `make_copy` function:

```cpp
StringBuffer make_copy(const StringBuffer& s)
{
    // make a new array of characters of the same size as s
    char* new_str = new char[s.size];

    // copy the characters from s to the new array
    for (int i = 0; i < s.size; i++)
    {
        new_str[i] = s.str[i];
    }
    
    return StringBuffer{new_str, s.size};
}
```
## The destroy_StringBuffer Function
To avoid memory leaks, we need to de-allocate a `StringBuffer` when we are finished with it. The `destroy_StringBuffer` function does this:
```cpp
void destroy_StringBuffer(StringBuffer& s)
{
    delete[] s.str;
    s.str = nullptr;
    s.size = -1;
}
```

This function de-allocates the underlying array that `s.str` points to. It also sets `s.str` to `nullptr` and `s.size` to -1, which, while not strictly necessary, is probably worthwhile since it makes it clearer that the `StringBuffer` is no longer valid. This is also the reason why `s` is *passed by reference*: pass by reference is gives `destroy_StringBuffer` access to modify the passed-in values in `s`.

**Be careful!** Nothing stops you from using a `StringBuffer` after it has been destroyed. If you accidentally (or on purpose!) use a destroyed `StringBuffer`, then your program will most likely crash.

**Important** Whenever you use pointers or `new`/`delete`, be sure to test your code with a memory checking tool like `valgrind` (on Linux) or `leaks` (on macOS) to ensure that you are not leaking memory. This is essential for library code like this --- programmers are trusting you to not leak memory!
## A Debugging Function
When writing a program it's often helpful to print out values to see if they are what we think they are. So lets add a function that prints a `StringBuffer` to the console:

```cpp
void debug(const StringBuffer& s)
{
    cout << "{\"";
    for (int i = 0; i < s.size; i++)
    {
        cout << s.str[i];
    }
    cout << "\", size: " << s.size << "}\n";
}
```

Regular users of this library wouldn't use this function: it's mainly a tool to help us debug our code as we write it.

Using `debug` let's us check that things are working the way we expect:

```cpp
StringBuffer s = make_StringBuffer("Hello");
debug(s);

StringBuffer t = make_StringBuffer(" World");
debug(t);

destroy_StringBuffer(s);
debug(s):
destroy_StringBuffer(t);
debug(t):
```

## The append Function
Let's implement the `append(s, other)` function, which modifies `s` to contain a copy of `other` on the end.

To do this, we'll first create a new array big enough to hold all the characters from both `s` and `other`, and then copy the characters from `s` and `other` into it. Then we de-allocate the old `s` array and set the pointer and size of `s` to be the new one:

```cpp
void append(StringBuffer& s, const StringBuffer& other)
{
    // make a new array big enough for both s and other
    char* new_str = new char[s.size + other.size];

    // copy the s characters to the new array
    for (int i = 0; i < s.size; i++)
    {
        new_str[i] = s.str[i];
    }

    // copy the other characters to the new array
    for (int i = 0; i < other.size; i++)
    {
        new_str[s.size + i] = other.str[i];
    }

    // de-allocate the old array
    delete[] s.str;

    // make s point to the new array and update the size
    s.str = new_str;
    s.size = s.size + other.size;
}
```

Notice a couple of things:

- In the function header, `s` is passed by *reference* since it is  modified. `t` is passed by *constant reference* since it is *not* modified.
- For a brief moment their's an extra array, i.e. before `new_str` is de-allocated we have both it and the old `s.str` array. This wastes memory, but it is necessary to ensure that the `s` array is updated correctly.
## Testing
In the source code at the end of this page, a testing function for each of the three string functions has been provided. They automatically check that the functions work with a few small strings. While passing these tests does not mean the functions are correct, those tests plus our careful implementation help increase our confidence in their correctness. 
## Conclusion
We've implemented a small, function-oriented library for working with C-style strings. It has these benefits:
- It's easier to use than a C-style string, since you don't need to worry as much about memory management. You never need to explicitly call `new` or `delete`.
- Getting the size of a `StringBuffer` is fast and easy: you just look at the `size` field.
- Appending a `StringBuffer` to another `StringBuffer` is easily done with the `append` function.
- It's straightforward to create your own helper functions to make working with `StringBuffer`s.

However, it is not perfect:

- **Nothing stops you from accidentally, or on purpose (!), modifying a `StringBuffer` in a way that breaks it**. For instance:
   ```cpp
    StringBuffer s = make_StringBuffer("Hello");
    s.size = 100; // mistake!
    ```
  Now `s` has the wrong size, and so `StringBuffer` functions will probably not work correctly on it.

- **Remembering to call `destroy_StringBuffer` exactly once when you are finished is easier said than done.** It's easy to forget to call it, or to call it too early or too late, or even to call it more than once.
- **The `append` function is not especially efficient**. Every time it is called it uses extra memory to copy the underlying array. Faster implementations are possible, e.g. you could make the underlying array a little larger then necessary and then only make a new array when you run out of this extra space.

Overall, while this is a good start that is probably easier to use then regular C-style strings, it is not as powerful, safe, or as efficient as `std::string`.
## Questions
1. Write a `void` function called `print(sb)` that prints the `StringBuffer` `sb` to the console.
2. What of instead of copying the underlying array in `make_copy` we just make the new `StringBuffer` point to the same array as the original. Why would this probably be a bad idea?
  ```cpp
  StringBuffer make_copy(const StringBuffer& s)
  {
      return StringBuffer{s.str, s.size};
  }
  ```

3. Write a `bool` function called `equals(sb1, sb2)` that returns `true` if the `StringBuffer`s `sb1` and `sb2` are equal, and `false` otherwise. Two `StringBuffer`s are equal if they have the same length and the same characters in the same order.

4. What happens if you called the `destroy_StringBuffer` function given above on  a `StringBuffer` that has already been destroyed? Try it and see! Is this the right behavior?

5. Modify `StringBuffer` to include a `bool` called `is_valid` that is `true` if the `StringBuffer` is valid, and `false` otherwise. Functions other than `make_StringBuffer` should now check if a `StringBuffer` is valid before using it.
6. What other tests cases do you think would be useful to add to the sample code below? 
## Sample Code
```cpp
// stringBuffer.cpp

#include <cassert>
#include <cstring>
#include <iostream>

using namespace std;

struct StringBuffer
{
    char* str;
    int size;
};

//
// Returns a new StringBuffer with the given text.
//
StringBuffer make_StringBuffer(const char* text)
{
    // get the length of the text
    int len = strlen(text);

    // allocate a new array of characters
    char* str = new char[len]; // no \0 at the end (!)

    // copy the characters from text to str
    for (int i = 0; i < len; i++)
    {
        str[i] = text[i];
    }

    // return the new StringBuffer
    return StringBuffer{str, len};
}

//
// Returns a new StringBuffer that is a copy of the given StringBuffer.
//
StringBuffer make_copy(const StringBuffer& s)
{
    // make a new array of characters of the same size as s
    char* new_str = new char[s.size];

    // copy the characters from s to the new array
    for (int i = 0; i < s.size; i++)
    {
        new_str[i] = s.str[i];
    }
    return StringBuffer{new_str, s.size};
}

//
// De-allocates the given StringBuffer.
//
// Sets the string to nullptr and the size to -1.
//
void destroy_StringBuffer(StringBuffer& s)
{
    delete[] s.str;
    s.str  = nullptr;
    s.size = -1;
}

//
// Appends StringBuffer other to the end of StringBuffer s.
//
// s is modified, and other is not changed.
//
void append(StringBuffer& s, const StringBuffer& other)
{
    // make a new array of characters of the total size of s and other
    char* new_str = new char[s.size + other.size];

    // copy the s characters to the new array
    for (int i = 0; i < s.size; i++)
    {
        new_str[i] = s.str[i];
    }

    // copy the other characters to the new array
    for (int i = 0; i < other.size; i++)
    {
        new_str[s.size + i] = other.str[i];
    }

    // de-allocate the old array
    delete[] s.str;

    // make s point to the new array and update the size
    s.str  = new_str;
    s.size = s.size + other.size;
}

//
// helper functions
//

void print(const StringBuffer& s)
{
    for (int i = 0; i < s.size; i++)
    {
        cout << s.str[i];
    }
}

void println(const StringBuffer& s)
{
    print(s);
    cout << "\n";
}

void debug(const StringBuffer& s)
{
    cout << "{\"";
    print(s);
    cout << "\", size: " << s.size << "}\n";
}

void debug2(const StringBuffer& s)
{
    cout << "{\"";
    for (int i = 0; i < s.size; i++)
    {
        cout << s.str[i];
    }
    cout << "\", size: " << s.size << "}\n";
}

void demo1()
{
    StringBuffer s = make_StringBuffer("Hello");
    cout << s.size << "\n";          // prints 5
    for (int i = 0; i < s.size; i++) // prints "Hello"
    {
        cout << s.str[i];
    }
    cout << "\n";

    StringBuffer t = make_StringBuffer(" World");
    cout << t.size << "\n"; // prints 6

    // append t to s, modifying s to be "Hello World"
    append(s, t);
    cout << s.size << "\n";          // prints 11
    for (int i = 0; i < s.size; i++) // prints "Hello World"
    {
        cout << s.str[i];
    }
    cout << "\n";

    destroy_StringBuffer(s);
    destroy_StringBuffer(t);
}

void demo2()
{
    StringBuffer s = make_StringBuffer("Hello");
    debug(s);

    StringBuffer t = make_copy(s);
    debug(t);

    append(s, t); // append t to s, modifying s to be "Hello World"
    debug(s);

    destroy_StringBuffer(s);
    destroy_StringBuffer(t);
}

//
// Test code
//

void test_make_StringBuffer()
{
    cout << "test_make_StringBuffer ...\n";
    // empty string
    StringBuffer s = make_StringBuffer("");
    assert(s.size == 0);
    destroy_StringBuffer(s);

    // single character
    s = make_StringBuffer("A");
    assert(s.size == 1);
    assert(s.str[0] == 'A');
    destroy_StringBuffer(s);

    // normal string
    s = make_StringBuffer("Hello");
    assert(s.size == 5);
    assert(s.str[0] == 'H');
    assert(s.str[1] == 'e');
    assert(s.str[2] == 'l');
    assert(s.str[3] == 'l');
    assert(s.str[4] == 'o');
    destroy_StringBuffer(s);

    cout << "... all test_make_StringBuffer tests passed\n";
}

void test_make_copy()
{
    cout << "test_make_copy ...\n";
    // empty string
    StringBuffer s = make_StringBuffer("");
    assert(s.size == 0);
    StringBuffer t = make_copy(s);
    assert(s.size == t.size);
    destroy_StringBuffer(s);
    destroy_StringBuffer(t);

    // single character
    s = make_StringBuffer("A");
    t = make_copy(s);
    assert(s.size == t.size);
    assert(s.str[0] == t.str[0]);
    destroy_StringBuffer(s);
    destroy_StringBuffer(t);

    // normal string
    s = make_StringBuffer("Hello");
    t = make_copy(s);
    assert(s.size == t.size);
    assert(s.str[0] == t.str[0]);
    assert(s.str[1] == t.str[1]);
    assert(s.str[2] == t.str[2]);
    assert(s.str[3] == t.str[3]);
    assert(s.str[4] == t.str[4]);
    destroy_StringBuffer(s);
    destroy_StringBuffer(t);

    cout << "... all test_make_copy tests passed\n";
}

void test_append()
{
    cout << "test_append ...\n";
    // append empty to empty
    StringBuffer empty = make_StringBuffer("");
    append(empty, empty);
    assert(empty.size == 0);
    destroy_StringBuffer(empty);

    // append empty to one character
    StringBuffer s = make_StringBuffer("A");
    empty          = make_StringBuffer("");
    append(s, empty);
    assert(s.size == 1);
    assert(s.str[0] == 'A');
    assert(empty.size == 0);
    destroy_StringBuffer(s);
    destroy_StringBuffer(empty);

    // append one character to empty
    s                   = make_StringBuffer("A");
    StringBuffer result = make_StringBuffer("");
    append(result, s);
    assert(result.size == 1);
    assert(result.str[0] == 'A');
    assert(s.size == 1);
    assert(s.str[0] == 'A');
    destroy_StringBuffer(s);
    destroy_StringBuffer(result);

    // append one character to one character
    s      = make_StringBuffer("A");
    result = make_StringBuffer("B");
    append(result, s);
    assert(result.size == 2);
    assert(result.str[0] == 'B');
    assert(result.str[1] == 'A');
    assert(s.size == 1);
    assert(s.str[0] == 'A');
    destroy_StringBuffer(s);
    destroy_StringBuffer(result);

    // append two regular strings
    result = make_StringBuffer("Hello");
    s      = make_StringBuffer("World");
    append(result, s);
    assert(result.size == 10);
    assert(result.str[0] == 'H');
    assert(result.str[1] == 'e');
    assert(result.str[2] == 'l');
    assert(result.str[3] == 'l');
    assert(result.str[4] == 'o');
    assert(result.str[5] == 'W');
    assert(result.str[6] == 'o');
    assert(result.str[7] == 'r');
    assert(result.str[8] == 'l');
    assert(result.str[9] == 'd');
    assert(s.size == 5);
    assert(s.str[0] == 'W');
    assert(s.str[1] == 'o');
    assert(s.str[2] == 'r');
    assert(s.str[3] == 'l');
    assert(s.str[4] == 'd');
    destroy_StringBuffer(s);
    destroy_StringBuffer(result);

    cout << "... all test_append tests passed\n";
}

int main()
{
    test_make_StringBuffer();
    test_make_copy();
    test_append();
    // demo1();
    // demo2();
} // main
```

