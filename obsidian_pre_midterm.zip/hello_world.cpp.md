```cpp
// hello_world.cpp

#include <iostream>

using namespace std;

int main() {
    cout << "Hello, world!\n";
}
```