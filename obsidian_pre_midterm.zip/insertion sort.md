#terminology

## Definition
A simple sorting algorithm divides a list into a sorted and unsorted part, and then repeatedly takes an element from the unsorted part and inserts into the correct position in the sorted part.

See [[Basic Sorting]] for a more in-depth discussion.